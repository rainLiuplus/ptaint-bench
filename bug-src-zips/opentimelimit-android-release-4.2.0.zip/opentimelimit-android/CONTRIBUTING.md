## bug reports and feature requests

- open a ticket here at GitLab
- alternatively, send a message to support@timelimit.io

## merge requests

Are possible but only after talking with the developer before developing anything.