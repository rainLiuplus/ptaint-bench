package im.r_c.android.clearweather.activity;

import android.support.v7.app.AppCompatActivity;

/**
 * ClearWeather
 * Created by richard on 16/4/29.
 */
public class BaseActivity extends AppCompatActivity {
}
