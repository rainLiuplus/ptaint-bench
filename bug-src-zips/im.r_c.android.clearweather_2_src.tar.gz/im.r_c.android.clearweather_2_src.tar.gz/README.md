# Clear Weather (清心天气) for Android

[![License](https://img.shields.io/github/license/mashape/apistatus.svg?maxAge=2592000)]()

<img src="./Images/Icons/1024x500 Play Store.png">

A weather application with a very clean UI and easy to use.

一款简洁明了的天气应用。

<a href="https://play.google.com/store/apps/details?id=im.r_c.android.clearweather" target="_blank"><img src="http://7xqspp.com1.z0.glb.clouddn.com/16-5-17/87299043.jpg"></a>

Google Play：https://play.google.com/store/apps/details?id=im.r_c.android.clearweather

fir.im (可直接下载)：http://fir.im/clearweather

## Credits

Thanks for [@桔子君_Joy](http://weibo.com/xujingjue)'s excellent icon design.

## Screenshots

<img src="./Images/Screenshots/s3.jpg" width="320">
<img src="./Images/Screenshots/s2.jpg" width="320">

<img src="./Images/Screenshots/s0.jpg" width="320">
<img src="./Images/Screenshots/s1.jpg" width="320">
