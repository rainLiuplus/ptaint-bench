package de.nulide.findmydevice.receiver;

public class DeviceAdminReceiver extends android.app.admin.DeviceAdminReceiver {


}
