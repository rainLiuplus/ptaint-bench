package de.nulide.findmydevice.data.io.json;

import java.util.LinkedList;

public class JSONLog extends LinkedList<JSONLogEntry> {

    public JSONLog(){

    }
}
