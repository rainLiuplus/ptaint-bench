package de.nulide.findmydevice.data.io.json;

import java.util.HashMap;

public class JSONMap extends HashMap<Integer, Object> {

    public JSONMap() {

    }
}
