package de.nulide.findmydevice.data.io.json;

import java.util.LinkedList;

public class JSONWhiteList extends LinkedList<JSONContact> {

    public JSONWhiteList() {

    }

}
