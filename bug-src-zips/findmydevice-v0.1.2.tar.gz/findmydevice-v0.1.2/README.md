# FindMyDevice

Find your Device via SMS.
This applications goal is to track your device when it's lost and should be a secure open source application and a alternative to Googles FindMyDevice.

[<img src="https://fdroid.gitlab.io/artwork/badge/get-it-on.png"
     alt="Get it on F-Droid"
     height="80">](https://f-droid.org/packages/de.nulide.findmydevice/)


# Why?

I have lost my  brand new phone last week.
I have to say, if i would have used Googles Services like (FindMyDevice) i could have a better chance to find it.
But why the heck did nobody created an open source application to find a lost device without giving up your privacy and feeding the big data crake Google.

If you like and want to support this project, spread the info about this application or donate.

# Contributors

John - [2br-2b](https://gitlab.com/2br-2b)

nvallas - [nvallas](https://gitlab.com/nvallas)

MijoHuer - [MijoHuer](https://gitlab.com/MijoHuer)

Rémi - [Remi-p](https://gitlab.com/Remi-p)

linux.redneck - [linux-redneck](https://gitlab.com/linux-redneck)

# Donate

<script src="https://liberapay.com/Nulide/widgets/button.js"></script>
<noscript><a href="https://liberapay.com/Nulide/donate"><img alt="Donate using Liberapay" src="https://liberapay.com/assets/widgets/donate.svg"></a></noscript>

# Why is it taking that long to fix x?

I am working full-time and have to learn for my tests.
This project is my free-time and i have spent a lot of time in this and still will.
If there are bugs i will try to fix them as soon as possible, but my full-time job has priority.
If it takes too long to fix something you can of course try to fix it by yourself and contribute to this project.

Thanks

Nulide
