#!/bin/bash

echo "sms send 123 message" | nc localhost 5554  > /dev/null
