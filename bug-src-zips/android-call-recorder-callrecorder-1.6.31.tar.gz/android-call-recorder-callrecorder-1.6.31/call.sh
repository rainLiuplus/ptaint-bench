#!/bin/bash

echo "gsm call 123" | nc localhost 5554  > /dev/null
