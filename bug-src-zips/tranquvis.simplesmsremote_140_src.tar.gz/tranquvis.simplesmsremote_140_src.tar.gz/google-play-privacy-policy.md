# Privacy Policy of Simple Sms Remote

The collected data is saved on the user's client device only.
No data is sended to a server or any other applications except of SMS messages.

## Camera
The application can take pictures.
A Picture is only taken when it is requested through a command message from a granted phone.
The pictures are stored on the client device as long as no one deletes them.

## Location 
Location is only fetched when it is requested through a command message from a granted phone.
The location is only responded to the phone, which sent the command.