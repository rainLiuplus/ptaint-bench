package tranquvis.simplesmsremote.Sms;

/**
 * Created by Andreas Kaltenleitner on 24.08.2016.
 */
public interface MyMessage {
    String getPhoneNumber();

    String getMessage();
}
