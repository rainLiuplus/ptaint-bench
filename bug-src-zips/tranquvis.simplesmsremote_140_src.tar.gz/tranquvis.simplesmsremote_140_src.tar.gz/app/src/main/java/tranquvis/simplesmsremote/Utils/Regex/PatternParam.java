package tranquvis.simplesmsremote.Utils.Regex;

/**
 * Created by Andreas Kaltenleitner on 25.10.2016.
 */

public class PatternParam {
    private String id;

    public PatternParam(String id) {
        this.id = id;
    }
}
