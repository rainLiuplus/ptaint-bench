package tranquvis.simplesmsremote.Data;

import java.io.Serializable;

/**
 * Created by Andreas Kaltenleitner on 18.10.2016.
 */

public abstract class ModuleSettingsData implements Serializable {

}
