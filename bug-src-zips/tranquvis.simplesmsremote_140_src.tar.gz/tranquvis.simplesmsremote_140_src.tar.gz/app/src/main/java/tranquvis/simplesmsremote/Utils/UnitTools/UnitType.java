package tranquvis.simplesmsremote.Utils.UnitTools;

public enum UnitType {
    TIME
}