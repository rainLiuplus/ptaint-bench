package tranquvis.simplesmsremote.Utils;

/**
 * Created by Andi on 04.09.2016.
 */
//unused so far
/*
public class ContactUtils {
    public static List<Contact> readContacts(Context context) {
        ContentResolver cr = context.getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

        List<Contact> contacts = new ArrayList<>();
        if (cur.getCount() > 0) {
            while (cur.moveToNext()) {
                String id = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                if (Integer.parseInt(cur.getString(cur.getColumnIndex(
                        ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {

                    // get all phone numbers of contact
                    Cursor pCur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        String phone = pCur.getString(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NUMBER));
                        contacts.add(new Contact(phone, name));
                    }
                    pCur.close();
                }
            }
        }

        return contacts;
    }

    public static class Contact {
        String phoneNumber;
        String name;

        public Contact(String phoneNumber, String name) {
            this.phoneNumber = phoneNumber;
            this.name = name;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public String getName() {
            return name;
        }

        @Override
        public String toString() {
            return name + " (" + phoneNumber + ")";
        }
    }
}
*/