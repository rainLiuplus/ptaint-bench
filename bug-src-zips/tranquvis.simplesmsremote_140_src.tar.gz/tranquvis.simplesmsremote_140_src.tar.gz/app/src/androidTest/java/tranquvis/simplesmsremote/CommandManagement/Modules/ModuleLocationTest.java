package tranquvis.simplesmsremote.CommandManagement.Modules;

/**
 * Created by Andreas Kaltenleitner on 10.11.2016.
 */
public class ModuleLocationTest extends ModuleTest {

}