package tranquvis.simplesmsremote.CommandManagement.Modules;

/**
 * Created by Andreas Kaltenleitner on 22.1.2018.
 */
public class ModuleAudioRecordingTest extends ModuleTest {

}