package tranquvis.simplesmsremote.CommandManagement.Modules;

/**
 * Created by Andreas Kaltenleitner on 31.10.2016.
 */
public class ModuleDisplayTest extends ModuleTest {

}