package tranquvis.simplesmsremote.CommandManagement.Modules;

/**
 * Created by Kaltenleitner Andreas on 29.10.2016.
 */
public class ModuleWifiHotspotTest extends ModuleTest {
}