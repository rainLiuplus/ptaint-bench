package tranquvis.directorypicker.Interfaces;

import java.io.File;

/**
 * Created by Andi on 04.05.2015.
 */
public interface RenameDirectoryDialogListener {
    void OnRenameRequested(File file, String title);
}
