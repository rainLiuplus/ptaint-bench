package tranquvis.directorypicker.Interfaces;

import java.io.File;

public interface DirectoryPickerListener
{
    void onDirPicked(File dir);
}
