package tranquvis.directorypicker.Interfaces;

/**
 * Created by Andi on 04.05.2015.
 */
public interface CreateDirectoryDialogListener
{
    void OnDirCreationRequested(String title);
}
