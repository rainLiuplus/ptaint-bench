#!/bin/bash

adb pull /sdcard/Audio\ Recorder/ .; adb shell rm "/sdcard/Audio\ Recorder/*"
