# Audio Recorder

Android friendly!

Audio Recorder with custom recording folder, nice recording volume indicator, recording notification, recording lock screen activity.

# Manual install

    gradle installDebug

# Translate

If you want to translate 'Audio Recorder' to your language  please read this:

  * [HOWTO-Translate.md](/docs/HOWTO-Translate.md)

# Screenshots

![shot](/docs/shot.png)

# Contributors

  * japanese translation thanks to @naofumi
  * german translation thanks to @vv01f
