package com.genonbeta.android.database;

/**
 * created by: Veli
 * date: 10.10.2017 17:37
 */

public enum SQLType
{
	INTEGER,
	DOUBLE,
	LONG,
	TEXT,
	DATE,
	BLOB,
	TIMESTAMP
}
