package com.genonbeta.TrebleShot.exception;

/**
 * created by: Veli
 * date: 6.01.2018 22:26
 */

public class DeviceNotFoundException extends NotFoundException
{
}
