package com.genonbeta.TrebleShot.util;

import android.support.design.widget.FloatingActionButton;

/**
 * created by: Veli
 * date: 3.01.2018 17:16
 */

public interface FABSupport
{
	public boolean onFABRequested(FloatingActionButton floatingActionButton);
}
