package com.genonbeta.TrebleShot.exception;

public class ThreadCancelledException extends Exception
{
}
