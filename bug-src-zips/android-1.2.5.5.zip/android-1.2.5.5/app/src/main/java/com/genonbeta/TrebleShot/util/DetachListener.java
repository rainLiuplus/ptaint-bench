package com.genonbeta.TrebleShot.util;

/**
 * created by: Veli
 * date: 19.11.2017 20:16
 */

public interface DetachListener
{
	void onPrepareDetach();
}
