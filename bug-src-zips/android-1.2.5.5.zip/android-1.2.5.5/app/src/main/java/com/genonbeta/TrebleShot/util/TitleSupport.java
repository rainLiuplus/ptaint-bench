package com.genonbeta.TrebleShot.util;

import android.content.Context;

/**
 * Created by: veli
 * Date: 11/16/16 10:33 AM
 */

public interface TitleSupport
{
	CharSequence getTitle(Context context);
}
