package com.genonbeta.TrebleShot.object;

/**
 * created by: Veli
 * date: 18.01.2018 20:57
 */

public interface Editable extends Comparable, Selectable
{
}
