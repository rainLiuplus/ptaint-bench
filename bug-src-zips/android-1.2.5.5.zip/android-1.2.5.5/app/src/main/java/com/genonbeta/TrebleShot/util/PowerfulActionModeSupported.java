package com.genonbeta.TrebleShot.util;

import com.genonbeta.TrebleShot.widget.PowerfulActionMode;

/**
 * created by: Veli
 * date: 19.11.2017 18:07
 */

public interface PowerfulActionModeSupported
{
	PowerfulActionMode getPowerfulActionMode();
}
