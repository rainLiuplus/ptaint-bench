package org.doublecheck.wifiscanner;

public interface MessagePublisher {
	public void setMessage(int message);
}
