package org.exobel.routerkeygen.utils;

/**
 * Created by dusanklinec on 01/03/2018.
 */

public interface WrappingListener {
    void onCall();
}
