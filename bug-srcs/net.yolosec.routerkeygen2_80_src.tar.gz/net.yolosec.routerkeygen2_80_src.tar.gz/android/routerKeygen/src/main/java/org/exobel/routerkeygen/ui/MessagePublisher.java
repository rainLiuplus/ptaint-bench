package org.exobel.routerkeygen.ui;

public interface MessagePublisher {
    void setMessage(int message);
}
