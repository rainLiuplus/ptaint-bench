package org.slf4j.impl;

import org.primftpd.log.PrimFtpdLoggerBinder;

public class StaticLoggerBinder extends PrimFtpdLoggerBinder {
}
