package org.primftpd.prefs;

import android.preference.PreferenceActivity;

/**
 * Defined in manifest with Theme. Required as it does not work to change theme
 * programmatically for {@link PreferenceActivity}.
 *
 */
public class FtpPrefsActivityThemeLight extends FtpPrefsActivity
{
}
