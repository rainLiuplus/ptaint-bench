package org.primftpd;

/**
 * Eventbus event to indicate server state changed.
 */
public class ServerStateChangedEvent {
}
