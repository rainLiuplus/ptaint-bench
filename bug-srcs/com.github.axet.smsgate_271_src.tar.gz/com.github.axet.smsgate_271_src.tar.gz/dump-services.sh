#!/bin/bash

adb shell dumpsys  activity  s
