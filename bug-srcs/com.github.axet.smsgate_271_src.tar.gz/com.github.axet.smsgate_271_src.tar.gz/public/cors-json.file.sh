#!/bin/bash

gsutil cors set cors-json.file.json gs://android-sms-gate.appspot.com
