adb logcat -s "SMSBackup+" "k9" "AndroidRuntime"
