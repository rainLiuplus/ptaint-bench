package com.zegoggles.smssync.preferences;

public enum AuthMode {
    PLAIN,
    XOAUTH
}
