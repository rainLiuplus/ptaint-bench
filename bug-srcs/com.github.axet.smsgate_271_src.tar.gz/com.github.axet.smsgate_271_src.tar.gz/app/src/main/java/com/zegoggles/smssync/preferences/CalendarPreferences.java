package com.zegoggles.smssync.preferences;

public class CalendarPreferences {
}
