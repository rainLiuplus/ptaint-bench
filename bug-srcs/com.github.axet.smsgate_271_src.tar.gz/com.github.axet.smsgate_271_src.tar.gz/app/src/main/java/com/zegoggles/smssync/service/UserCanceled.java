package com.zegoggles.smssync.service;

public class UserCanceled {
}
