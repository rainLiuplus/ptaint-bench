package com.github.axet.smsgate.app;

import com.fsck.k9.mail.internet.MimeMessage;

public class TagMimeMessage extends MimeMessage {
    public Object tag;
}
