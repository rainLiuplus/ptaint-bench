package com.zegoggles.smssync.service.exception;

public interface LocalizableException {
    int errorResourceId();
}
