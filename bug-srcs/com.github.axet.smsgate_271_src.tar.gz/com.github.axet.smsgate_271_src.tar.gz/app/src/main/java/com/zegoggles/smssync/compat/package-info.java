/**
 * The purpose of this package is compatibility with Kitkat+ versions
 * of Android. All the implementations are stubs and not actually used.
 */
package com.zegoggles.smssync.compat;
