#!/bin/bash

adb shell dumpsys alarm
