# Block6

### Privacy Policy

The Block6 app does not collect or transmit personal data for any reason.
