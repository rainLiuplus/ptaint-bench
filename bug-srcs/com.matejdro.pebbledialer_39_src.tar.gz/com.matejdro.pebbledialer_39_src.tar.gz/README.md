PebbleDialer-Android
====================

Android part of the Dialer for Pebble app.

Watch counterpart: https://github.com/matejdro/PebbleDialer-Watchapp  
Google Play Store entry: https://play.google.com/store/apps/details?id=com.matejdro.pebbledialer  
Discussion forums: https://plus.google.com/communities/105292167808840816317

## Building

To build this project, just pull the repo and open it in Android Studio. If it starts complaining about missing `PebbleAndroidCommons`, make sure you also pulled the submodules.