package com.matejdro.pebbledialer.ui;

import android.content.SharedPreferences;

public interface PreferenceSource
{
    SharedPreferences getCustomPreferences();
}
