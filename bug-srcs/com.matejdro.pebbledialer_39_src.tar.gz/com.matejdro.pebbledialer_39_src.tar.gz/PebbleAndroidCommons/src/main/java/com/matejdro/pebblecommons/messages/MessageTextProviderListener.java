package com.matejdro.pebblecommons.messages;

public interface MessageTextProviderListener
{
    void gotText(String text);
}
