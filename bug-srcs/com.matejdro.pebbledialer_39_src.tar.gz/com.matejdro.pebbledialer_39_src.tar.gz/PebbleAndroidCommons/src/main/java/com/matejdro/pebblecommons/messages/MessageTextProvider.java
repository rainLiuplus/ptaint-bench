package com.matejdro.pebblecommons.messages;

import android.content.Context;

public interface MessageTextProvider
{

    public void startRetrievingText(MessageTextProviderListener textListener);
}
