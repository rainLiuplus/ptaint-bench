This is an incomplete list of what Omnidroid can do or will do in the near future. I believe talented and creative guys like you can found much more cool things that Omnidroid help to make your life easier and better. If you have any suggest feature or new user stories, share with us.

_Active Development:_

o If you are pissed off with ur bf/gf or some advertising company, and just
want to delete their sms's without reading them, then Omnidroid will delete them from
inbox or auto reply “leave me alone!”.<br>
o If you can not remember where you left your android phone at home, just send an Email to your phone/gmail account with the subject line as “Find me!”. Your android phone will ring at max volume to help you find it.<br>
o If I receiving and incoming calls and our phone is in "silent" mode, then<br>
automatically reply with an SMS message.<br>
o If the power level is low, and we receive and incoming call,<br>
automatically ignore the call.<br>
o Automatic sent sms/email wishing Happy Birthday at a certain time, or a meeting reminder. <br>

<i>Wishlist:</i>

o android phone is lost -> Send an email which contains GPS location <br>
o 1st event of the day -> Alarm Wake up<br>
o Birthday -> Toast Action<br>
o Cold/Rainy Weather -> Toast Msg/Suggest Clothing<br>
o Toast Action -> Email/SMS/Call<br>
o Date/Time -> Suggest Meals<br>
o Email Recd -> Organize/respond based on status<br>
o Location -> Set phone profile<br>
o calendar event notification -> send an automatic email or SMS to a recipient or list of recipients.<br>
o Set Mood -> Choose Music Playlist<br>
o Update profile on one app -> Update profile on others<br>
o New song playing -> update away msg<br>
o Specific song plays -> Picture Display<br>
o Get email from a contact -> Queue song associated with them<br>
o Locale coordinate changes -> BooRah (Restaurant listings and reviews)<br>
o Alert on Stock Ticker -> Send email to Broker<br>
o Update "Not Well" Status -> Send notification to Bosses/Friends<br>
o WiFi network -> Automatically connect<br>
o Time is Midnight -> Email daily phone usage summary<br>
o If location is changing rapidly -> Activate GPS logging to keep track of speed/path/etc, send email or publish somewhere.<br>
o Phone rings at wrong time -> Turn the phone over or shake it will make it silence<br>