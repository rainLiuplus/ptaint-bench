State Transition Diagram which was used as the basis for the PhoneStateMachine class. Also take note on how omnidroid determines if a phone call has ended in the diagram

![http://omnidroid.googlecode.com/svn/docs/stateflow/PhoneState.png](http://omnidroid.googlecode.com/svn/docs/stateflow/PhoneState.png)