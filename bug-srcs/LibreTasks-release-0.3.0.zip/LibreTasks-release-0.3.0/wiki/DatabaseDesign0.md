# Introduction #

Our data model design based on sqlite3 databases


# Diagram #
![http://omnidroid.googlecode.com/svn/docs/omnidroid_db.png](http://omnidroid.googlecode.com/svn/docs/omnidroid_db.png)<br />