# Introduction #

Flow of the event handling core from receiving a system intent to launching a list of actions.


# Flow Diagram #

![http://omnidroid.googlecode.com/svn/docs/EventFlow.jpg](http://omnidroid.googlecode.com/svn/docs/EventFlow.jpg)<br>