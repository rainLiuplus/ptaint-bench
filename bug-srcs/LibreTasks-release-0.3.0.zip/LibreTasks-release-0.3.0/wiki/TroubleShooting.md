# General Problems #

## `[`Solved - [Issue6](https://code.google.com/p/omnidroid/issues/detail?id=6)`]` Emulator instances cannot see each other ##
I get this error when I am trying to send SMS to (or call) other running emulator: <br />
emulator: could not connect client socket to :::::::00001:5556: Invalid argument.

Workarounds:
Disable IPv6 (use IPv4), or wait for the next release of Android.

See [Issue 6](https://code.google.com/p/omnidroid/issues/detail?id=6) for more information.