#### General information
<!-- App version can be e.g. v0.1.1
     System e.g. Android 7.0.1, Nexus 5X -->

* **App version:** 
* **System:** 

#### Description
<!--What this is about, what happens and how. What needs to be done for it to happen.-->


#### Log
<!-- adb logcat -s io.github.gsantner.memetastic -->
