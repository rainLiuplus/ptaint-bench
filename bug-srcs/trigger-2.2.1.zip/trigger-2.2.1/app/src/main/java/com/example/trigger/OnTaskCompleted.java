package com.example.trigger;

public interface OnTaskCompleted {
    void onTaskCompleted(DoorReply result);
}
