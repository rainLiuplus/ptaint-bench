package io.github.sds100.keymapper

/**
 * Created by sds100 on 21/10/2018.
 */

enum class StateChange {
    ENABLE, DISABLE, TOGGLE
}