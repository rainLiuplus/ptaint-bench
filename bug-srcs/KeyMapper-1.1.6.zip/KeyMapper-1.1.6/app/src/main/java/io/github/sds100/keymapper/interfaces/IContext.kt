package io.github.sds100.keymapper.interfaces

import android.content.Context

/**
 * Created by sds100 on 25/11/2018.
 */
interface IContext {
    val ctx: Context
}