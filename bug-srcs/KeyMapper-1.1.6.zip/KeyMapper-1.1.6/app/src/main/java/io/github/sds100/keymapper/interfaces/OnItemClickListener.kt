package io.github.sds100.keymapper.interfaces

interface OnItemClickListener<T> {
    fun onItemClick(item: T)
}