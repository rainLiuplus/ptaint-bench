package io.github.sds100.keymapper.activity

import io.github.sds100.keymapper.fragment.HelpFragment

/**
 * Created by sds100 on 19/12/2018.
 */

class HelpActivity : SimpleFragmentActivity() {
    override val fragmentToShow = HelpFragment()
}