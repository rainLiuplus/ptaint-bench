package io.github.sds100.keymapper.selection

/**
 * Created by sds100 on 09/09/2018.
 */
abstract class SelectableItem {
    abstract val id: Long
}