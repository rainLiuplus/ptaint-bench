package io.github.sds100.keymapper.activity

import io.github.sds100.keymapper.fragment.AboutFragment

/**
 * Created by sds100 on 10/12/2018.
 */

class AboutActivity : SimpleFragmentActivity() {
    override val fragmentToShow = AboutFragment()
}