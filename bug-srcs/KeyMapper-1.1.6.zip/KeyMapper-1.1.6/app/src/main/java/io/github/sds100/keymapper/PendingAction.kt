package io.github.sds100.keymapper

/**
 * Created by sds100 on 01/04/2019.
 */

abstract class PendingAction(val trigger: Trigger) : Runnable