package io.github.sds100.keymapper.activity

import io.github.sds100.keymapper.fragment.SettingsFragment

/**
 * Created by sds100 on 10/12/2018.
 */

class SettingsActivity : SimpleFragmentActivity() {
    override val fragmentToShow = SettingsFragment()
}