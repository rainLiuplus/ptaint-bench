package io.github.sds100.keymapper

/**
 * Created by sds100 on 29/11/2018.
 */
data class SectionItem(val header: String)