package io.github.sds100.keymapper.interfaces

/**
 * Created by sds100 on 11/05/2019.
 */

interface OnLogChangedListener {
    fun onLogChange()
}