package de.srlabs.gsmmap;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.security.KeyStore;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.widget.Toast;

/**
 * @author Andreas Schildbach
 */
public class UploadService extends IntentService {

  public static final String ACTION_UPLOAD_STATE = "upload_state";
  private Handler handler = new Handler();

  public static void upload(final Context context, final File file) {

    if (file == null) throw new IllegalArgumentException();

    final Intent intent = new Intent(context, UploadService.class);
    intent.putExtra("filename", file.getAbsolutePath());
    context.startService(intent);
  }

  public UploadService() {
    super(UploadService.class.getName());
  }

  @Override
  protected void onHandleIntent(final Intent intent) {

    final String filename = intent.getStringExtra("filename");

    upload(filename);
  }

  private boolean upload(final String filename) {

    final PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
    final WakeLock wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getClass().getName());

    boolean success = false;

    InputStream is = null;
    Writer out = null;

    final Intent broadcast = new Intent(ACTION_UPLOAD_STATE);
    broadcast.setPackage(getPackageName());

    try {

      final File file = new File(filename);
      final URL url = new URL(Constants.UPLOAD_URL);

      Log.i(Constants.LOG_TAG, "uploading " + file + " to " + url);

      broadcast.putExtra(ACTION_UPLOAD_STATE, file.getName());
      sendStickyBroadcast(broadcast);

      final HttpURLConnection connection = (HttpURLConnection) url.openConnection();

      if (connection instanceof HttpsURLConnection) {
        final InputStream keystoreInputStream = getAssets().open("keystore.bks");

        final KeyStore keystore = KeyStore.getInstance("BKS");
        keystore.load(keystoreInputStream, "password".toCharArray());
        keystoreInputStream.close();

        final TrustManagerFactory tmf = TrustManagerFactory.getInstance("X509");
        tmf.init(keystore);

        final SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, tmf.getTrustManagers(), null);

        ((HttpsURLConnection) connection).setSSLSocketFactory(sslContext.getSocketFactory());
      }

      connection.setConnectTimeout((int) Constants.CONNECT_TIMEOUT);
      connection.setReadTimeout((int) Constants.READ_TIMEOUT);
      connection.setRequestMethod("POST");
      connection.setRequestProperty("content-type",
                                    "multipart/form-data;boundary=" + Constants.MULTIPART_BOUNDARY);
      connection.setInstanceFollowRedirects(false);
      connection.setDoOutput(true);
      connection.connect();

      String fileName = file.getName();

      is = new FileInputStream(file);

      final OutputStream os = connection.getOutputStream();
      out = new OutputStreamWriter(os);

      out.write("--" + Constants.MULTIPART_BOUNDARY + Constants.CRLF);
      out.write("Content-Disposition: form-data; name=\"opaque\"" + Constants.CRLF);
      out.write(Constants.CRLF);
      out.write("1" + Constants.CRLF);

      out.write("--" + Constants.MULTIPART_BOUNDARY + Constants.CRLF);
      out.write("Content-Disposition: form-data; name=\"bursts\"; filename=\"" + fileName
                + "\""
                + Constants.CRLF);
      out.write(Constants.CRLF);
      out.flush();

      byte[] buffer = new byte[32 * 1024];
      int n = 0;
      int counter = 0;
      while (-1 != (n = is.read(buffer))) {
        counter += n;
        Log.d(Constants.LOG_TAG, "Upload counter: " + counter);
        os.write(buffer, 0, n);
        os.flush();
      }

      out.write(Constants.CRLF);
      out.write("--" + Constants.MULTIPART_BOUNDARY + "--" + Constants.CRLF);
      out.flush();

      final int responseCode = connection.getResponseCode();
      if (responseCode == HttpURLConnection.HTTP_OK) {
        success = true;
        file.delete();
        Log.i(Constants.LOG_TAG, "uploading succeeded");
      } else if (responseCode == HttpURLConnection.HTTP_MOVED_TEMP) {
        Log.w(Constants.LOG_TAG, "upload redirected: " + connection.getHeaderField("Location"));
      } else {
        Log.w(Constants.LOG_TAG, "uploading failed: " + responseCode + " " + connection.getResponseMessage());
      }

    } catch (final IOException x) {
      Log.e(Constants.LOG_TAG, "error uploading file: " + x.getMessage());

      handler.post(new Runnable() {
        @Override
        public void run() {
          Toast.makeText(UploadService.this, "Error uploading file: " + x.getMessage(), Toast.LENGTH_LONG)
               .show();
        }
      });
    } catch (final GeneralSecurityException x) {
      Log.e(Constants.LOG_TAG, "error uploading file: " + x.getMessage());

      handler.post(new Runnable() {
        @Override
        public void run() {
          Toast.makeText(UploadService.this, "Error uploading file: " + x.getMessage(), Toast.LENGTH_LONG)
               .show();
        }
      });
    } finally {

      if (out != null) {
        try {
          out.close();
        } catch (final IOException x) {
          // swallow
        }
      }

      if (is != null) {
        try {
          is.close();
        } catch (final IOException x) {
          // swallow
        }
      }

      if (wakeLock.isHeld()) wakeLock.release();

      broadcast.removeExtra(ACTION_UPLOAD_STATE);
      sendStickyBroadcast(broadcast);
    }

    return success;
  }
}
