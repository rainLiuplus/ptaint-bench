package de.srlabs.gsmmap;

/**
 * @author Andreas Schildbach
 */
public interface TestStateMachine {

  public enum Event {
    TEL_IDLE, TEL_RINGING, TEL_DIALING, SMS_INCOMING, SMS_SENT, API_SUCCESS, API_FAIL, TIMEOUT
  }

  void start();

  void event(Event event);
}
