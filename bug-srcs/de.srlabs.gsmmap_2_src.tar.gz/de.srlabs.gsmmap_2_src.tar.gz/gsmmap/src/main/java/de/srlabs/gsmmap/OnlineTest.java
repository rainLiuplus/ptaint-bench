package de.srlabs.gsmmap;

import java.io.File;

import android.util.Log;

/**
 * @author Andreas Schildbach
 */
public class OnlineTest implements TestStateMachine {

  private final ScriptActions actions;
  private final PhoneServiceConnectionHandler phoneServiceConnectionHandler;
  private final int maxIterations;

  // state
  private final Buckets buckets;
  private State state;

  private enum State {
    CALL_MO, CALL_MO_ACTIVE, SMS_MO, CALL_MT, CALL_MT_ACTIVE, SMS_MT, END
  }

  public OnlineTest(final ScriptActions actions,
                    final PhoneServiceConnectionHandler phoneServiceConnectionHandler,
                    final int maxIterations,
                    final Buckets buckets) {

    this.actions = actions;
    this.phoneServiceConnectionHandler = phoneServiceConnectionHandler;
    this.maxIterations = maxIterations;
    this.buckets = buckets != null ? buckets : new Buckets();
  }

  @Override
  public void start() {
    iterate();
  }

  private void iterate() {

    final String network = actions.determineNetwork();
    final String connectionType = actions.determineConnectionType();
    final String bucketPrefix = network + "-" + connectionType + "-";

    if (buckets.getBucket(bucketPrefix + Buckets.CALL_MO) < maxIterations) {
      Log.i(Constants.LOG_TAG, "begin call_mo iteration");
      setState(State.CALL_MO);
      actions.triggerCallMo(false);
    } else if (buckets.getBucket(bucketPrefix + Buckets.SMS_MO) < maxIterations) {
      Log.i(Constants.LOG_TAG, "begin sms_mo iteration");
      setState(State.SMS_MO);
      actions.triggerSmsMo();
    } else if (buckets.getBucket(bucketPrefix + Buckets.CALL_MT) < maxIterations) {
      Log.i(Constants.LOG_TAG, "begin call_mt iteration");
      setState(State.CALL_MT);
      actions.triggerApiCallback();
    } else if (buckets.getBucket(bucketPrefix + Buckets.SMS_MT) < maxIterations) {
      Log.i(Constants.LOG_TAG, "begin sms_mt iteration");
      setState(State.SMS_MT);
      actions.triggerApiSmsback();
    } else {
      Log.i(Constants.LOG_TAG, "end");
      setState(State.END);
      actions.stop();
    }
  }

  @Override
  public void event(final Event event) {

    if (state == null) {
      throw new IllegalStateException("call start() first");
    } else if (state == State.CALL_MO && event == Event.TEL_DIALING) {
      setState(State.CALL_MO_ACTIVE);
    } else if (state == State.CALL_MO_ACTIVE && event == Event.TEL_IDLE) {
      collectAndIterate(Buckets.CALL_MO);
    } else if (state == State.SMS_MO && event == Event.SMS_SENT) {
      collectAndIterate(Buckets.SMS_MO);
    } else if (state == State.CALL_MT && event == Event.API_SUCCESS) {
      // expected
    } else if (state == State.CALL_MT && event == Event.API_FAIL) {
      failAndIterate(Buckets.CALL_MT);
    } else if (state == State.CALL_MT && event == Event.TIMEOUT) {
      failAndIterate(Buckets.CALL_MT);
    } else if (state == State.CALL_MT && event == Event.TEL_RINGING) {
      setState(State.CALL_MT_ACTIVE);
      actions.removeTimeout();
      actions.dropCall();
    } else if (state == State.CALL_MT_ACTIVE && event == Event.TEL_IDLE) {
      collectAndIterate(Buckets.CALL_MT);
    } else if (state == State.SMS_MT && event == Event.API_SUCCESS) {
      // expected
    } else if (state == State.SMS_MT && event == Event.API_FAIL) {
      failAndIterate(Buckets.SMS_MT);
    } else if (state == State.SMS_MT && event == Event.TIMEOUT) {
      failAndIterate(Buckets.SMS_MT);
    } else if (state == State.SMS_MT && event == Event.SMS_INCOMING) {
      actions.removeTimeout();
      collectAndIterate(Buckets.SMS_MT);
    } else {
      Log.w(Constants.LOG_TAG, "unexpected: state=" + state + " event=" + event);
    }
  }

  private void collectAndIterate(final String bucketPostfix) {

    final String network = actions.determineNetwork();
    final String connectionType = actions.determineConnectionType();

    final String bucket = network + "-" + connectionType + "-" + bucketPostfix;
    final int count = buckets.incrementBucket(bucket, true);

    actions.broadcastState("collect", buckets);

    collectLog(network + "-" + actions.determineCell(), connectionType, bucketPostfix, count, new Runnable() {
      @Override
      public void run() {
        iterate();
      }
    });
  }

  private void failAndIterate(final String bucketPostfix) {

    final String network = actions.determineNetwork();
    final String connectionType = actions.determineConnectionType();

    final String bucket = network + "-" + connectionType + "-" + bucketPostfix;
    buckets.incrementBucket(bucket, false);

    iterate();
  }

  private void collectLog(final String network,
                          final String connectionType,
                          final String stateName,
                          final int iteration,
                          final Runnable continueRunnable) {

    phoneServiceConnectionHandler.collectData(connectionType,
                                              network,
                                              stateName,
                                              iteration,
                                              new LogsCollectedCallback() {

                                                @Override
                                                public void onContinue() {
                                                  continueRunnable.run();
                                                }

                                                @Override
                                                public void onFileWritten(final File logfile) {}
                                              });
  }

  private void setState(final State state) {
    Log.d(Constants.LOG_TAG, "state: " + state);
    this.state = state;
    actions.broadcastState(state.name(), buckets);
  }
}
