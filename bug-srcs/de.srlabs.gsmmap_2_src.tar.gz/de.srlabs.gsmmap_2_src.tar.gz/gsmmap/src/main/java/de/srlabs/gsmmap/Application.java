package de.srlabs.gsmmap;

import android.content.Intent;
import android.util.Log;

import java.lang.Thread.UncaughtExceptionHandler;

/**
 * @author Andreas Schildbach
 */
public class Application extends android.app.Application {

  @Override
  public void onCreate() {

    Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {

      private final UncaughtExceptionHandler previousHandler = Thread.getDefaultUncaughtExceptionHandler();

      @Override
      public void uncaughtException(final Thread thread, final Throwable x) {
        Log.e(Constants.LOG_TAG, "exception in " + thread.getName() + " thread", x);
        previousHandler.uncaughtException(thread, x);
      }
    });

    super.onCreate();

    final Intent scriptStateBroadcast = new Intent(ScriptService.ACTION_SCRIPT_STATE);
    scriptStateBroadcast.setPackage(getPackageName());
    removeStickyBroadcast(scriptStateBroadcast);

    final Intent uploadStateBroadcast = new Intent(UploadService.ACTION_UPLOAD_STATE);
    uploadStateBroadcast.setPackage(getPackageName());
    removeStickyBroadcast(uploadStateBroadcast);

    Log.d(Constants.LOG_TAG, "Deleting old log files...");

    Utils.deleteLogFilesWithPrefix(new String[] { Constants.LOG_FILE_S2_PREFIX,
                                                 Constants.LOG_FILE_S2_PREFIX_AENAES,
                                                 Constants.LOG_FILE_S3_PREFIX,
                                                 Constants.LOG_FILE_XGS_PREFIX });

   Log.i(Constants.LOG_TAG, "application created");
  }

}
