package de.srlabs.gsmmap;

import java.io.File;

/**
 * @author Andreas Schildbach
 */
public interface ScriptActions {

  void triggerCallMo(boolean callback);

  void triggerSmsMo();

  void dropCall();

  void triggerApiCallback();

  void triggerApiSmsback();

  void stop();

  void startTimeout(long ms);

  void removeTimeout();

  void broadcastState(String state, Buckets buckets);

  void uploadFile(File logfile);

  String determineNetwork();

  String determineCell();

  String determineConnectionType();
}
