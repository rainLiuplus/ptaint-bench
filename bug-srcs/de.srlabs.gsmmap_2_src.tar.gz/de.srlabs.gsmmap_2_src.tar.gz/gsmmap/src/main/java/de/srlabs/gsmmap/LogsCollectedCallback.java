package de.srlabs.gsmmap;

import java.io.File;

public interface LogsCollectedCallback {
  void onContinue();

  void onFileWritten(File logfile);
}
