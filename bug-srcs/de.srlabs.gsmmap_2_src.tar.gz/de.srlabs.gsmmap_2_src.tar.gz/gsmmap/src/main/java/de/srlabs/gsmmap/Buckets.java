package de.srlabs.gsmmap;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import android.util.Log;

/**
 * @author Andreas Schildbach
 */
public class Buckets extends HashMap<String, int[]> implements Serializable {

  public static final int NUM_PHASE_BUCKETS = 4;
  public static final String CALL_MO = "call_mo";
  public static final String CALL_MT = "call_mt";
  public static final String SMS_MO = "sms_mo";
  public static final String SMS_MT = "sms_mt";

  public static final String BUCKET_2G = "GSM";
  public static final String BUCKET_3G = "3G";

  public Buckets() {}

  public Buckets(final Map<String, int[]> buckets) {
    if (buckets != null) this.putAll(buckets);
  }

  public int getBucket(final String bucket) {
    final int[] counts = get(bucket);
    return counts != null ? counts[0] + counts[1] : 0;
  }

  public int getBucket(final String bucket, final boolean success) {
    final int[] counts = get(bucket);
    return counts != null ? counts[success ? 0 : 1] : 0;
  }

  public int incrementBucket(final String bucket, final boolean success) {

    int[] counts = get(bucket);

    if (counts == null) {
      counts = new int[2];
      put(bucket, counts);
    }

    final int count = ++counts[success ? 0 : 1];

    Log.i(Constants.LOG_TAG, "incremented bucket " + bucket
                             + " to "
                             + count
                             + (success ? " successes" : " fails"));

    return count;
  }

  public int getBucketSum(final String bucketPrefix, final boolean success) {

    return getBucket(bucketPrefix + CALL_MO, success) + getBucket(bucketPrefix + SMS_MO, success)
           + getBucket(bucketPrefix + CALL_MT, success)
           + getBucket(bucketPrefix + SMS_MT, success);
  }

  public boolean isBucketFull(final String bucketPrefix, final int max) {

    if (getBucket(bucketPrefix + CALL_MO) < max) return false;
    if (getBucket(bucketPrefix + SMS_MO) < max) return false;
    if (getBucket(bucketPrefix + CALL_MT) < max) return false;
    if (getBucket(bucketPrefix + SMS_MT) < max) return false;

    return true;
  }

  public void clearFails() {
    for (final int[] counts : values())
      counts[1] = 0;
  }

  public static String otherModeBucket(final String bucketPrefix) {
    if (bucketPrefix.endsWith("-" + BUCKET_2G + "-"))
      return bucketPrefix.substring(0, bucketPrefix.length() - BUCKET_2G.length() - 2) + "-"
             + BUCKET_3G
             + "-";
    else if (bucketPrefix.endsWith("-" + BUCKET_3G + "-"))
      return bucketPrefix.substring(0, bucketPrefix.length() - BUCKET_3G.length() - 2) + "-"
             + BUCKET_2G
             + "-";
    else
      throw new IllegalStateException();
  }

  public static String networkOperator(final String bucketPrefix) {
    return bucketPrefix.substring(0, bucketPrefix.indexOf('-'));
  }

  public static String networkMode(final String bucketPrefix) {
    if (bucketPrefix.endsWith("-" + BUCKET_2G + "-"))
      return BUCKET_2G;
    else if (bucketPrefix.endsWith("-" + BUCKET_3G + "-"))
      return BUCKET_3G;
    else
      throw new IllegalStateException();
  }
}
