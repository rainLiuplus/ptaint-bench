package de.srlabs.gsmmap;

import static de.srlabs.gsmmap.Constants.LOG_TAG;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

/**
 * @author flashmop
 */
public class PhoneServiceConnectionHandler implements Closeable {

  private final Context context;
  private Handler handler;
  private Handler triggerHandler;
  private Handler ramdumpHandler;
  private Messenger triggerModeMessenger;
  private Messenger ramdumpModeMessenger;
  private ServiceConnection mSecPhoneServiceConnection;
  private Messenger mServiceMessenger;

  private Map<Integer, ModemLogCopier> copiersMap = new HashMap<Integer, ModemLogCopier>();
  private Integer mapsKey = 0;

  private Map<Integer, LogsCollectedCallback> logsCollectedCallbackMap = new HashMap<Integer, LogsCollectedCallback>();

  public PhoneServiceConnectionHandler(Context context) {

    this.context = context;

    initHandler();
    initRamDumpHandler();
    initPhoneServiceConnection();
    connectToRilService();

  }

  /**
   * @param callback
   *          s run method is called when the logfile is created.
   */
  public void collectData(String connectionType,
                          String network,
                          String action,
                          int iteration,
                          LogsCollectedCallback callback) {

    final int tmpMapKey = mapsKey++;

    final long timestamp = System.currentTimeMillis();

    final Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    calendar.setTimeInMillis(timestamp);

    final String outFileName = String.format(Locale.US,
                                             "xgs.%s.%04d%02d%02d-%02d%02d%02d.%s.%s.%s.%d.log",
                                             Build.MODEL,
                                             calendar.get(Calendar.YEAR),
                                             calendar.get(Calendar.MONTH) + 1,
                                             calendar.get(Calendar.DAY_OF_MONTH),
                                             calendar.get(Calendar.HOUR_OF_DAY),
                                             calendar.get(Calendar.MINUTE),
                                             calendar.get(Calendar.SECOND),
                                             connectionType,
                                             network,
                                             action,
                                             iteration);

    Log.i(LOG_TAG, "collecting ril log #" + tmpMapKey + " into " + outFileName);

    logsCollectedCallbackMap.put(tmpMapKey, callback);

    final ModemLogCopier copier = new ModemLogCopier(outFileName, context, timestamp);

    copiersMap.put(tmpMapKey, copier);

    triggerLogDump(tmpMapKey);
  }

  private void triggerLogDump(Integer index) {
    byte[] data = startSysDumpData(18);

    //    invokeOemRilRequestRaw(data, triggerHandler.obtainMessage(1014), triggerModeMessenger);
    invokeOemRilRequestRaw(data, triggerHandler.obtainMessage(index), triggerModeMessenger);
  }

  private byte[] startSysDumpData(int i) {
    DataOutputStream dataoutputstream;
    ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();

    try {
      dataoutputstream = new DataOutputStream(bytearrayoutputstream);

      dataoutputstream.writeByte(7);
      dataoutputstream.writeByte(i);
      Log.d(LOG_TAG, "cmd: " + i);
      dataoutputstream.writeShort(5);
      dataoutputstream.writeByte(0);

    } catch (IOException ioexception) {
      Log.d(LOG_TAG, "IOException in startSysDumpData!!!");
      return null;
    }

    return bytearrayoutputstream.toByteArray();
  }

  private void invokeOemRilRequestRaw(byte abyte0[], Message message, Messenger messenger) {
    Log.d(Constants.LOG_TAG, "invokeOemRilRequestRaw()");
    try {
      Bundle bundle = message.getData();
      bundle.putByteArray("request", abyte0);
      message.setData(bundle);
      message.replyTo = messenger;

      mServiceMessenger.send(message);

      SystemClock.sleep(200);

    } catch (RemoteException remoteexception) {
      Log.d(LOG_TAG, "RemoteException", remoteexception);

      return;
    }
  }

  private void connectToRilService() {
    Log.i(LOG_TAG, "Connect To Ril service...");
    Intent intent = new Intent();
    intent.setClassName("com.sec.phone", "com.sec.phone.SecPhoneService");
    context.bindService(intent, mSecPhoneServiceConnection, 1);
  }

  private void initRamDumpHandler() {
    ramdumpHandler = new Handler() {
      @Override
      public void handleMessage(Message msg) {

        if (msg.getData().getInt("error") == 0) {
          Log.d(Constants.LOG_TAG, "Ramdumpmode set");
        } else {
          Log.d(Constants.LOG_TAG, "Ramdumpmode error");
        }
      }
    };
  }

  public void initHandler() {
    triggerHandler = new Handler() {

      @Override
      public void handleMessage(Message message) {
        Log.d(LOG_TAG, "message: " + message);
        final Integer mapIndex = message.what;

        final ModemLogCopier copier = copiersMap.remove(mapIndex);
        final LogsCollectedCallback callback = logsCollectedCallbackMap.remove(mapIndex);

        Log.d(LOG_TAG, "DONE: " + message.what);
        if (message.getData().getInt("error") == 0) {
          Log.d(LOG_TAG, "MODEMLOG_DONE Success");

          Log.d(LOG_TAG, "message.getData(): " + message.getData());
          Log.i(Constants.LOG_TAG, "callback.onContinue()...");
          Log.i(LOG_TAG, "collecting ril log #" + mapIndex
                         + " continue, took "
                         + (System.currentTimeMillis() - copier.getTimestamp())
                         + " ms");
          callback.onContinue();

          copier.writeFileToSdcard(new Runnable() {
            @Override
            public void run() {
              Log.i(LOG_TAG, "collecting ril log #" + mapIndex
                             + " done, took "
                             + (System.currentTimeMillis() - copier.getTimestamp())
                             + " ms");
                if(Utils.isGalaxyS2()) {
                    Utils.deleteLogFilesWithPrefix(new String[] { Constants.LOG_FILE_S2_PREFIX_AENAES });
                }
              callback.onFileWritten(copier.getOutFile());
            }
          },
                                   mapIndex);

        } else {
          Log.w(LOG_TAG, "MODEMLOG_DONE fail");

          handler.post(new Runnable() {
              @Override
              public void run() {
                  Toast.makeText(context, "Dumping Modemlog failed", Toast.LENGTH_LONG).show();
              }
          });

        }
      }
    };
  }

  private void initPhoneServiceConnection() {

    triggerModeMessenger = new Messenger(triggerHandler);
    ramdumpModeMessenger = new Messenger(ramdumpHandler);

    mSecPhoneServiceConnection = new ServiceConnection() {

      @Override
      public void onServiceConnected(ComponentName componentname, IBinder ibinder) {
        Log.d(LOG_TAG, "onServiceConnected()");
        mServiceMessenger = new Messenger(ibinder);
        //        bindservice_flag = 1;

        ramdumpMode(1);
      }

      @Override
      public void onServiceDisconnected(ComponentName componentname) {
        Log.d(LOG_TAG, "onServiceDisconnected()");
        mServiceMessenger = null;
      }
    };
  }

  private void ramdumpMode(int i) {
    Log.d(Constants.LOG_TAG, "ramdumpMode(" + i + ")");
    try {
      ByteArrayOutputStream bytearrayoutputstream;
      DataOutputStream dataoutputstream;
      bytearrayoutputstream = new ByteArrayOutputStream();
      dataoutputstream = new DataOutputStream(bytearrayoutputstream);
      //        mOem.getClass();
      dataoutputstream.writeByte(7);
      //        mOem.getClass();
      dataoutputstream.writeByte(10);
      dataoutputstream.writeShort(5);
      dataoutputstream.writeByte(i);
      //        Exception exception;
      //        IOException ioexception1;

      dataoutputstream.close();
      dataoutputstream.close();

      invokeOemRilRequestRaw(bytearrayoutputstream.toByteArray(),
                             ramdumpHandler.obtainMessage(1007),
                             ramdumpModeMessenger);

    } catch (IOException e) {
      Log.e("sysDump", "ioexception: ", e);
    }
  }

  @Override
  public void close() {
    Log.d(Constants.LOG_TAG, "Closing service connection");
    context.unbindService(mSecPhoneServiceConnection);
  }
}
