package de.srlabs.gsmmap;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Map;

import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.telephony.CellLocation;
import android.telephony.PhoneStateListener;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;
import android.telephony.gsm.SmsManager;
import android.util.Log;

import com.android.internal.telephony.ITelephony;

import de.srlabs.gsmmap.TestStateMachine.Event;

/**
 * @author Andreas Schildbach
 */
public final class ScriptService extends Service implements ScriptActions {

  public static final String ACTION_SCRIPT_STATE = "script_state";
  public static final String ACTION_SCRIPT_BUCKETS = "script_buckets";

  public static void start(final Context context,
                           final String ownNumber,
                           final boolean isConnected,
                           final Buckets initialBuckets) {
    final Intent intent = new Intent(context, ScriptService.class);
    intent.putExtra("own_number", ownNumber);
    intent.putExtra("connected", isConnected);
    intent.putExtra("initial_buckets", initialBuckets);
    context.startService(intent);
  }

  public static void cancel(final Context context) {
    context.startService(new Intent(ACTION_CANCEL, null, context, ScriptService.class));
  }

  private TelephonyManager telephonyManager;
  private PhoneServiceConnectionHandler phoneServiceConnectionHandler;
  private TestStateMachine stateMachine;
  private String ownNumber;

  private final Handler handler = new Handler();

  private long serviceCreatedAt;

  private final static String ACTION_CANCEL = new String("cancel");
  private final static String ACTION_SMS_SENT = new String("sms_sent");

  @Override
  public IBinder onBind(final Intent intent) {
    return null;
  }

  @Override
  public void onCreate() {

    serviceCreatedAt = System.currentTimeMillis();

    super.onCreate();

    Log.i(Constants.LOG_TAG, ScriptService.class.getName() + " created");

    telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
    telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);

    phoneServiceConnectionHandler = new PhoneServiceConnectionHandler(this);

    final IntentFilter intentFilter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
    intentFilter.setPriority(Integer.MAX_VALUE); // we mean it
    registerReceiver(smsReceiver, intentFilter);
  }

  @Override
  public void onDestroy() {

    handler.removeCallbacksAndMessages(null);

    unregisterReceiver(smsReceiver);

    telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);

    Log.i(Constants.LOG_TAG,
          ScriptService.class.getName() + " destroyed, was up for "
              + ((System.currentTimeMillis() - serviceCreatedAt) / 1000 / 60)
              + " minutes");

    phoneServiceConnectionHandler.close();
    phoneServiceConnectionHandler = null;

    super.onDestroy();
  }

  @Override
  public int onStartCommand(final Intent intent, final int flags, final int startId) {

    final String action = intent.getAction();

    if (ACTION_CANCEL.equals(action)) {

      Log.i(Constants.LOG_TAG, "Cancel!");
      stop();
      broadcastState("cancel", null);

    } else if (ACTION_SMS_SENT.equals(action)) {

      if (stateMachine != null) {

        Log.i(Constants.LOG_TAG, "received " + ACTION_SMS_SENT);

        stateMachine.event(Event.SMS_SENT);
      }
    } else {

      final int maxIterations = Constants.MAX_ITERATIONS;

      // time out
      handler.postDelayed(new Runnable() {
        @Override
        public void run() {
          Log.w(Constants.LOG_TAG, "Timeout!");
          stop();
          broadcastState("timeout", null);
        }
      }, Constants.TEST_TIMEOUT * maxIterations);

      ownNumber = intent.getStringExtra("own_number");
      final boolean isConnected = intent.getBooleanExtra("connected", false);
      final Buckets initialBuckets = new Buckets((Map<String, int[]>) intent.getSerializableExtra("initial_buckets"));
      initialBuckets.clearFails();

      stateMachine = isConnected ? new OnlineTest(this,
                                                  phoneServiceConnectionHandler,
                                                  maxIterations,
                                                  initialBuckets)
                                : new OfflineTest(this,
                                                  phoneServiceConnectionHandler,
                                                  maxIterations,
                                                  initialBuckets);

      stateMachine.start();
    }

    return START_NOT_STICKY;
  }

  private ITelephony getITelephony() {
    try {
      final Method method = Class.forName(telephonyManager.getClass().getName())
                                 .getDeclaredMethod("getITelephony");
      method.setAccessible(true);
      return (ITelephony) method.invoke(telephonyManager);
    } catch (Exception x) {
      Log.e(Constants.LOG_TAG, "error invoking undocumented getITelephony() api", x);
    }
    return null;
  }

  private final PhoneStateListener phoneStateListener = new PhoneStateListener() {
    @Override
    public void onCallStateChanged(final int state, final String incomingNumber) {

      if (stateMachine == null) return;

      Log.i(Constants.LOG_TAG, "onCallStateChanged(" + state + "," + incomingNumber + ")");

      if (state == TelephonyManager.CALL_STATE_IDLE)
        stateMachine.event(Event.TEL_IDLE);
      else if (state == TelephonyManager.CALL_STATE_OFFHOOK)
        stateMachine.event(Event.TEL_DIALING);
      else if (state == TelephonyManager.CALL_STATE_RINGING)
        stateMachine.event(Event.TEL_RINGING);
      else
        Log.d(Constants.LOG_TAG, "unhandled call state: " + state);
    }
  };

  private final SmsReceiver smsReceiver = new SmsReceiver() {
    @Override
    protected void onReceiveSms(final SmsMessage sms) {

      if (stateMachine == null) return;

      Log.i(Constants.LOG_TAG, "onReceiveSms(" + sms.getOriginatingAddress()
                               + ",\""
                               + sms.getMessageBody()
                               + "\")");

      stateMachine.event(Event.SMS_INCOMING);
    };
  };

  private final Runnable timeoutRunnable = new Runnable() {
    @Override
    public void run() {

      if (stateMachine == null) return;

      Log.i(Constants.LOG_TAG, "phase timeout");

      stateMachine.event(Event.TIMEOUT);
    }
  };

  @Override
  public void triggerCallMo(final boolean callback) {

    final Uri telUri = Uri.parse("tel:" + (callback ? Constants.CALLBACK_NUMBER : Constants.CALL_NUMBER));
    Log.i(Constants.LOG_TAG, "calling out to " + telUri);
    final Intent intent = new Intent(Intent.ACTION_CALL, telUri);
    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    startActivity(intent);
  }

  @Override
  public void triggerSmsMo() {

    final PendingIntent sentIntent = PendingIntent.getService(this, 0, new Intent(ACTION_SMS_SENT,
                                                                                  null,
                                                                                  this,
                                                                                  ScriptService.class), 0);
    Log.i(Constants.LOG_TAG, "sending sms to invalid destination");
    SmsManager.getDefault().sendTextMessage(Constants.SMS_NUMBER,
                                            Constants.SMS_CENTER,
                                            "This is a test sms",
                                            sentIntent,
                                            null);
  }

  @Override
  public void dropCall() {

    try {
      getITelephony().endCall();
    } catch (final RemoteException x) {
      Log.e(Constants.LOG_TAG, "error while dropping call", x);
    }
  }

  @Override
  public void triggerApiCallback() {

    if (!ownNumber.isEmpty()) {
      new ApiCall(ApiCall.Action.CALL, ownNumber, getAssets()) {

        @Override
        protected void onSuccess() {
          // stateMachine.event(Event.API_SUCCESS);
        }

        @Override
        protected void onFail() {
          stateMachine.event(Event.API_FAIL);
        }
      }.start();

      startTimeout(Constants.CALLBACK_TIMEOUT);

    } else {
      handler.post(new Runnable() {
        @Override
        public void run() {
          stateMachine.event(Event.API_FAIL);
        }
      });
    }
  }

  @Override
  public void triggerApiSmsback() {

    if (!ownNumber.isEmpty()) {
      new ApiCall(ApiCall.Action.SMS, ownNumber, getAssets()) {

        @Override
        protected void onSuccess() {
          // stateMachine.event(Event.API_SUCCESS);
        }

        @Override
        protected void onFail() {
          stateMachine.event(Event.API_FAIL);
        }
      }.start();

      startTimeout(Constants.SMSBACK_TIMEOUT);

    } else {
      handler.post(new Runnable() {
        @Override
        public void run() {
          stateMachine.event(Event.API_FAIL);
        }
      });
    }
  }

  @Override
  public void stop() {

    stopSelf();
  }

  @Override
  public void startTimeout(final long ms) {

    handler.postDelayed(timeoutRunnable, ms);
  }

  @Override
  public void removeTimeout() {

    handler.removeCallbacks(timeoutRunnable);
  }

  @Override
  public void broadcastState(final String state, final Buckets buckets) {

    final Intent broadcast = new Intent(ACTION_SCRIPT_STATE);
    broadcast.setPackage(getPackageName());
    broadcast.putExtra(ACTION_SCRIPT_STATE, state);
    if (buckets != null) broadcast.putExtra(ACTION_SCRIPT_BUCKETS, buckets);

    sendStickyBroadcast(broadcast);
  }

  @Override
  public void uploadFile(final File file) {
    UploadService.upload(this, file);
  }

  @Override
  public String determineNetwork() {

    return telephonyManager.getNetworkOperator();
  }

  @Override
  public String determineCell() {

    final StringBuilder cell = new StringBuilder();

    final CellLocation cellLocation = telephonyManager.getCellLocation();
    if (cellLocation instanceof GsmCellLocation) {
      final GsmCellLocation gsmCellLocation = (GsmCellLocation) cellLocation;
      cell.append(Integer.toHexString(gsmCellLocation.getLac()));
      cell.append("-");
      cell.append(Integer.toHexString(gsmCellLocation.getCid()));
    } else if (cellLocation instanceof CdmaCellLocation) {
      // final CdmaCellLocation cdmaCellLocation = (CdmaCellLocation) cellLocation;
      // network.append(Integer.toString(cdmaCellLocation.getNetworkId()));
      // network.append("-");
      // network.append(Integer.toString(cdmaCellLocation.getBaseStationId()));
    } else {
      throw new IllegalStateException();
    }

    return cell.toString();
  }

  @Override
  public String determineConnectionType() {
    return Utils.networkToConnectionType(telephonyManager.getNetworkType());
  }
}
