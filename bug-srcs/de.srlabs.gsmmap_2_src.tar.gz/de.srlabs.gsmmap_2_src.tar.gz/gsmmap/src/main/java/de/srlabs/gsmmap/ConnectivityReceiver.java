package de.srlabs.gsmmap;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

/**
 * @author Andreas Schildbach
 */
public class ConnectivityReceiver extends BroadcastReceiver {

  @Override
  public void onReceive(final Context context, final Intent intent) {

    final ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
    final NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

    final NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
    if (networkInfo != null) {

      final int networkType = networkInfo.getType();

      final boolean isWellConnected = networkInfo.isConnected() && (networkType == ConnectivityManager.TYPE_WIFI || networkType == ConnectivityManager.TYPE_ETHERNET);
      Log.i(Constants.LOG_TAG, "is " + (isWellConnected ? "" : "not ") + "well connected");

      if (isWellConnected && Utils.uploadSize(context.getApplicationContext()) > 0) {
        final Notification.Builder notification = new Notification.Builder(context);
        notification.setSmallIcon(android.R.drawable.stat_sys_warning);
        notification.setTicker("Don't forget to upload the GSMmap logs.");
        notification.setContentTitle("Don't forget to upload the GSMmap logs.");
        notification.setContentText("Now would be a good time for doing that, since you seem to be well connected");
        notification.setContentIntent(PendingIntent.getActivity(context, 0, new Intent(context,
                                                                                       MainActivity.class), 0));
        notification.setWhen(System.currentTimeMillis());
        notification.setAutoCancel(true);
        notificationManager.notify(0, notification.getNotification());
      } else {
        notificationManager.cancel(0);
      }
    } else {
      notificationManager.cancel(0);
    }
  }
}
