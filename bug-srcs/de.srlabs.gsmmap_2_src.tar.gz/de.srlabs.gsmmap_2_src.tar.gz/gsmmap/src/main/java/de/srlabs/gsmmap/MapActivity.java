package de.srlabs.gsmmap;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;

/**
 * @author Andreas Schildbach
 */
public class MapActivity extends Activity {

  @Override
  protected void onCreate(final Bundle savedInstanceState) {

    super.onCreate(savedInstanceState);

    setContentView(R.layout.activity_map);

    final WebView map = (WebView) findViewById(R.id.map_webview);
    map.getSettings().setJavaScriptEnabled(true);

    final Button contributeButton = (Button) findViewById(R.id.map_button_contribute);
    contributeButton.setOnClickListener(new OnClickListener() {

      @Override
      public void onClick(final View view) {

        final Builder dialog = new AlertDialog.Builder(MapActivity.this);
        dialog.setMessage(R.string.intro);
        dialog.setPositiveButton("OK", new Dialog.OnClickListener() {

          @Override
          public void onClick(final DialogInterface dialog, final int which) {

            startActivity(new Intent(MapActivity.this, MainActivity.class));
            finish();
          }
        });
        dialog.setNegativeButton("Cancel", null);
        dialog.show();
      }
    });

    final TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
    final String networkOperator = telephonyManager.getNetworkOperator();
    final String mapUrl;
    if (networkOperator != null && networkOperator.length() >= 3)
      mapUrl = Constants.MAP_URL + "?n=" + networkOperator.substring(0, 3);
    else
      mapUrl = Constants.MAP_URL;
    Log.i(Constants.LOG_TAG, "map url: " + mapUrl);
    map.loadUrl(mapUrl);
  }
}
