package de.srlabs.gsmmap;

import java.io.File;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import eu.chainfire.libsuperuser.Shell;

/**
 * @author Andreas Schildbach
 */
public class MainActivity extends Activity {

  private Button startButton;
  private Button uploadButton;
  private TextView uploadStateView;

  private SharedPreferences prefs;
  private TelephonyManager telephonyManager;

  private BroadcastReceiver internalBroadcastReceiver;
  private BroadcastReceiver connectivityBroadcastReceiver;
  private final PhoneStateListener phoneStateListener = new PhoneStateListener() {

    @Override
    public void onDataConnectionStateChanged(final int state, final int networkType) {
      updateView();
    }
  };

  // state
  private Buckets buckets;
  private boolean suAvailable = false;
  private String scriptState = null;
  private String uploadState = null;
  private boolean isConnected = false;
  private final Map<String, String> networkOperatorNames = new HashMap<String, String>();

  @Override
  protected void onCreate(Bundle savedInstanceState) {

    super.onCreate(savedInstanceState);

    prefs = PreferenceManager.getDefaultSharedPreferences(this);

    telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

    setContentView(R.layout.activity_main);

    startButton = (Button) findViewById(R.id.start_button);
    startButton.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(final View v) {
        if (isStartableState() || isContinuableState()) {
          final String ownNumber = telephonyManager.getLine1Number();
          final String lastConfirmedOwnNumber = prefs.getString(Constants.PREFS_KEY_OWN_NUMBER, "");
          if ((ownNumber == null || ownNumber.isEmpty()) || !lastConfirmedOwnNumber.isEmpty()) {
            final EditText editText = new EditText(MainActivity.this);
            editText.setHint("intl. notation, start with '+'");
            editText.setInputType(InputType.TYPE_CLASS_PHONE);
            final String text = lastConfirmedOwnNumber.isEmpty() ? "+" : lastConfirmedOwnNumber;
            editText.setText(text);
            editText.setSelection(text.length());

            final AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
            dialog.setTitle("Confirm your phone number");
            dialog.setView(editText);
            dialog.setPositiveButton("Run", new DialogInterface.OnClickListener() {

              @Override
              public void onClick(final DialogInterface dialog, final int which) {
                final String confirmedOwnNumber = editText.getText().toString().trim();
                prefs.edit().putString(Constants.PREFS_KEY_OWN_NUMBER, confirmedOwnNumber).commit();
                handleStart(confirmedOwnNumber.isEmpty() ? ownNumber : confirmedOwnNumber);
              }
            });
            dialog.setNegativeButton("Cancel", null);
            dialog.show();
          } else {
            handleStart(ownNumber);
          }
        } else {
          handleCancel();
        }
      }

      private void handleStart(final String ownNumber) {
        ScriptService.start(MainActivity.this, ownNumber, isConnected, buckets);
      }

      private void handleCancel() {
        ScriptService.cancel(MainActivity.this);
      }
    });

    uploadButton = (Button) findViewById(R.id.upload_button);
    uploadButton.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(final View v) {
        for (final File file : getExternalFilesDir(null).listFiles())
          UploadService.upload(MainActivity.this, file);
      }
    });

    uploadStateView = (TextView) findViewById(R.id.upload_state);

    internalBroadcastReceiver = new BroadcastReceiver() {

      @Override
      public void onReceive(final Context context, final Intent intent) {

        final String action = intent.getAction();

        if (ScriptService.ACTION_SCRIPT_STATE.equals(action)) {
          scriptState = intent.getStringExtra(ScriptService.ACTION_SCRIPT_STATE);
          if (intent.hasExtra(ScriptService.ACTION_SCRIPT_BUCKETS)) buckets = new Buckets((Map<String, int[]>) intent.getSerializableExtra(ScriptService.ACTION_SCRIPT_BUCKETS));
        } else if (UploadService.ACTION_UPLOAD_STATE.equals(action)) {
          uploadState = intent.getStringExtra(UploadService.ACTION_UPLOAD_STATE);
        }

        updateView();
      }
    };

    final IntentFilter intentFilter = new IntentFilter(ScriptService.ACTION_SCRIPT_STATE);
    intentFilter.addAction(UploadService.ACTION_UPLOAD_STATE);
    registerReceiver(internalBroadcastReceiver, intentFilter);

    connectivityBroadcastReceiver = new BroadcastReceiver() {
      @Override
      public void onReceive(final Context context, final Intent intent) {
        isConnected = !intent.getBooleanExtra(ConnectivityManager.EXTRA_NO_CONNECTIVITY, false);

        updateView();
      }
    };

    registerReceiver(connectivityBroadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));

    telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_DATA_CONNECTION_STATE);

    // force permission grant early
    if (Utils.isRootNeededForRead()) {
      new Thread() {
        @Override
        public void run() {
          final boolean suAvailable = Shell.SU.available();
          runOnUiThread(new Runnable() {
            @Override
            public void run() {
              MainActivity.this.suAvailable = suAvailable;
              updateView();
            }
          });
        }
      }.start();
    }

    updateView();
  }

  @Override
  protected void onResume() {

    super.onResume();

    updateView();
  }

  @Override
  public void onDestroy() {

    telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);

    unregisterReceiver(connectivityBroadcastReceiver);

    unregisterReceiver(internalBroadcastReceiver);

    super.onDestroy();
  }

  @Override
  public boolean onCreateOptionsMenu(final Menu menu) {
    super.onCreateOptionsMenu(menu);
    getMenuInflater().inflate(R.menu.main_options, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(final MenuItem item) {
    switch (item.getItemId()) {
    case R.id.main_options_switch_mode:
      handleSwitchMode();
      return true;
    case R.id.main_options_switch_network:
      handleSwitchNetwork();
      return true;
    }

    return super.onOptionsItemSelected(item);
  }

  private void handleSwitchNetwork() {
    startActivity(new Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS));
  }

  private void handleSwitchMode() {
    startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
  }

  private void updateView() {

    final TextView stateView = (TextView) findViewById(R.id.state);
    final TextView stateMsgView = (TextView) findViewById(R.id.state_msg);
    final TextView networkView = (TextView) findViewById(R.id.network);
    final TextView networkMsgView = (TextView) findViewById(R.id.network_msg);
    final View mode2G = findViewById(R.id.mode_2g);
    final View mode3G = findViewById(R.id.mode_3g);
    final LinearLayout progress2G = (LinearLayout) findViewById(R.id.progress_2g);
    final LinearLayout progress3G = (LinearLayout) findViewById(R.id.progress_3g);

    if (isStartableState()) {

      stateView.setText(null);
      stateMsgView.setText(null);
      startButton.setEnabled(suAvailable);
      startButton.setText("Run test");
      startButton.setKeepScreenOn(false);

    } else {

      startButton.setEnabled(true);

      if (isContinuableState()) {
        startButton.setText("Continue");
        startButton.setKeepScreenOn(false);
      } else {
        startButton.setText("Stop test");
        startButton.setKeepScreenOn(true);
      }

      final String scriptStateLc = scriptState.toLowerCase(Locale.US);
      final String stateResName = "state_" + scriptStateLc;

      final int stateResId = getResources().getIdentifier(stateResName, "string", getPackageName());
      if (stateResId != 0) {
        stateView.setText(stateResId);
      } else {
        Log.w(Constants.LOG_TAG, "no string for state: " + stateResName);
        stateView.setText(stateResName);
      }

      final int stateMsgResId = getResources().getIdentifier("msg_" + scriptStateLc,
                                                             "string",
                                                             getPackageName());
      if (stateMsgResId != 0) {
        stateMsgView.setText(stateMsgResId);
      } else {
        stateMsgView.setText(null);
      }
    }

    Log.d(Constants.LOG_TAG, "buckets: " + buckets);

    final String networkOperator = telephonyManager.getNetworkOperator();
    final String networkOperatorName = telephonyManager.getNetworkOperatorName();
    if (networkOperatorName != null) networkOperatorNames.put(networkOperator, networkOperatorName);

    networkView.setText(networkOperatorName != null ? networkOperatorName : networkOperator);

    final String bucket2GPrefix = networkOperator + "-" + Buckets.BUCKET_2G + "-";
    final String bucket3GPrefix = networkOperator + "-" + Buckets.BUCKET_3G + "-";
    final String connectionType = Utils.networkToConnectionType(telephonyManager.getNetworkType());

    final String bucketPrefix;
    final String otherBucketPrefix;
    final boolean bucketFull;
    final boolean otherBucketFull;

    if (connectionType != null) {
      bucketPrefix = networkOperator + "-" + connectionType + "-";
      otherBucketPrefix = Buckets.otherModeBucket(bucketPrefix);
      bucketFull = buckets != null && buckets.isBucketFull(bucketPrefix, Constants.MAX_ITERATIONS);
      otherBucketFull = buckets != null && buckets.isBucketFull(otherBucketPrefix, Constants.MAX_ITERATIONS);
    } else {
      bucketPrefix = null;
      otherBucketPrefix = null;
      bucketFull = false;
      otherBucketFull = false;
    }

    mode2G.setVisibility(Buckets.BUCKET_2G.equals(connectionType) ? View.VISIBLE : View.INVISIBLE);
    mode3G.setVisibility(Buckets.BUCKET_3G.equals(connectionType) ? View.VISIBLE : View.INVISIBLE);

    final int max = Buckets.NUM_PHASE_BUCKETS * Constants.MAX_ITERATIONS;

    progress2G.setWeightSum(max);
    final int success2g = buckets != null ? buckets.getBucketSum(bucket2GPrefix, true) : 0;
    final int fail2g = buckets != null ? buckets.getBucketSum(bucket2GPrefix, false) : 0;
    ((LinearLayout.LayoutParams) progress2G.getChildAt(0).getLayoutParams()).weight = success2g;
    ((LinearLayout.LayoutParams) progress2G.getChildAt(1).getLayoutParams()).weight = max - (success2g + fail2g);
    ((LinearLayout.LayoutParams) progress2G.getChildAt(2).getLayoutParams()).weight = fail2g;
    progress2G.requestLayout();

    progress3G.setWeightSum(max);
    final int success3g = buckets != null ? buckets.getBucketSum(bucket3GPrefix, true) : 0;
    final int fail3g = buckets != null ? buckets.getBucketSum(bucket3GPrefix, false) : 0;
    ((LinearLayout.LayoutParams) progress3G.getChildAt(0).getLayoutParams()).weight = success3g;
    ((LinearLayout.LayoutParams) progress3G.getChildAt(1).getLayoutParams()).weight = max - (success3g + fail3g);
    ((LinearLayout.LayoutParams) progress3G.getChildAt(2).getLayoutParams()).weight = fail3g;
    progress3G.requestLayout();

    if (bucketFull) {
      networkMsgView.setVisibility(View.VISIBLE);
      final StringBuilder networkViewText = new StringBuilder();
      final String bucketNetworkOperator = Buckets.networkOperator(bucketPrefix);
      final String bucketNetworkOperatorName = networkOperatorNames.containsKey(bucketNetworkOperator) ? networkOperatorNames.get(bucketNetworkOperator)
                                                                                                      : bucketNetworkOperator;
      networkViewText.append("You have collected sufficient ").append(Buckets.networkMode(bucketPrefix));
      networkViewText.append(" data from network ").append(bucketNetworkOperatorName).append(". ");
      networkViewText.append("To continue testing, please switch to ");
      final String otherBucketNetworkOperator = Buckets.networkOperator(otherBucketPrefix);
      if (otherBucketFull) {
        networkViewText.append("some other network by pressing NETWORK. ");
        networkViewText.append("After connecting to the network, press \"back\" to return to this window.");
      } else if (!(otherBucketNetworkOperator.equals(bucketNetworkOperator))) {
        final String otherBucketNetworkOperatorName = networkOperatorNames.containsKey(otherBucketNetworkOperator) ? networkOperatorNames.get(otherBucketNetworkOperator)
                                                                                                                  : otherBucketNetworkOperator;
        networkViewText.append("network ").append(otherBucketNetworkOperatorName);
        networkViewText.append(" by pressing NETWORK. ");
        networkViewText.append("After connecting to another network, press \"back\" to return to this window. ");
        networkViewText.append("NOTE: This will only work if you are roaming.");
      } else {
        final String otherNetworkMode = Buckets.networkMode(otherBucketPrefix);
        networkViewText.append("mode ").append(otherNetworkMode);
        networkViewText.append(" by pressing MODE > \"Mobile networks\" > \"Network mode\" > ");
        networkViewText.append("<b>" + (Buckets.BUCKET_2G.equals(otherNetworkMode) ? "GSM only"
                                                                                  : "WCDMA only") + "</b>");
        networkViewText.append(". ");
        networkViewText.append("Then, press \"back\" until you return to this window.");
      }
      networkMsgView.setText(Html.fromHtml(networkViewText.toString()));
    } else {
      networkMsgView.setVisibility(View.GONE);
    }

    if (uploadState != null) {
      uploadStateView.setText("Uploading " + uploadState + "…");
      uploadButton.setEnabled(false);
    } else {
      uploadStateView.setText(null);
      uploadButton.setEnabled(isConnected);
    }

    final long uploadSize = Utils.uploadSize(this);

    if (uploadSize > 0) {
      uploadButton.setVisibility(View.VISIBLE);
      uploadButton.setText(String.format("Upload logs (%.1f MB)", uploadSize / 1024f / 1024f));
    } else {
      uploadButton.setVisibility(View.INVISIBLE);
    }
  }

  private boolean isStartableState() {
    return scriptState == null;
  }

  private boolean isContinuableState() {
    return "end".equalsIgnoreCase(scriptState) || "timeout".equalsIgnoreCase(scriptState)
           || "cancel".equalsIgnoreCase(scriptState);
  }
}
