package de.srlabs.gsmmap;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import eu.chainfire.libsuperuser.Shell;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;
import java.util.zip.GZIPOutputStream;

import static de.srlabs.gsmmap.Constants.LOG_DIR_FILE;
import static de.srlabs.gsmmap.Constants.LOG_TAG;

public class ModemLogCopier {

  public static final int BUFFER_SIZE = 512 * 1024;
  public static final int MATCH_LENGTH = 1024;
  private static final int MAX_RETRY = 10;

  private String outFileName;
  private Handler handler = new Handler();
  private Context context;
  private File outFile;

  private long timestamp;

  private static byte[] match;

  public ModemLogCopier(String outFileName, Context context, long timestamp) {
    this.outFileName = outFileName;
    this.context = context;
    this.timestamp = timestamp;
  }

  public void writeFileToSdcard(final Runnable copyFileCallback, final int index) {
    Log.d(LOG_TAG, "writeFileToSdCard()");

    handler.postDelayed(new Runnable() {
      @Override
      public void run() {
        new Thread(new Runnable() {
          @Override
          public void run() {
            Log.d(LOG_TAG, "getDumpFile()");

            String dumpfile = getDumpFile();
            if (dumpfile != null) {
              if (Build.MODEL.equals(Constants.MODEL_S2)) {
                Shell.SU.run("chmod 777 " + LOG_DIR_FILE.toString());

              }

              Log.d(LOG_TAG, "   dumpFile: " + dumpfile);
              Log.d(LOG_TAG, "outFileName: " + outFileName);
              String sourceFile = LOG_DIR_FILE.toString() + File.separator + dumpfile;
              final String xgsFile = LOG_DIR_FILE.toString() + File.separator + outFileName;

              List<String> result = Shell.SU.run("mv " + sourceFile + " " + xgsFile);

              if (result != null) {
                for (String r : result) {
                  Log.d(LOG_TAG, "r: " + r);
                }
              }
              outFile = new File(context.getExternalFilesDir(null), outFileName + ".gz");
              try {
                copyAndGzipFile(new File(xgsFile), outFile, index);
                if (deleteFile(xgsFile)) {
                  Log.d(LOG_TAG, "Deleted: " + xgsFile);
                } else {

                  Log.e(LOG_TAG, "Deletion failed: " + xgsFile);
                }
              } catch (final IOException e) {

                Log.e(LOG_TAG, "Error while copying file #" + index, e);
              }

              if (Build.MODEL.equals(Constants.MODEL_S2)) {
                Shell.SU.run("chmod 774 " + LOG_DIR_FILE.toString());
              }
                } else {
              Log.e(LOG_TAG, "No dump file found");
            }
            copyFileCallback.run();
          }
        }).start();
      }
    },/* We need to wait until the files is actually written */
                        3000);
    //TODO: wait for the file to show up and then wait until it is not growing anymore
    //TODO: We need a progress indicator here
  }

  private boolean deleteFile(String xgsFile) {
    File file = new File(xgsFile);

    boolean success = file.delete();

    if (!success) {
      List<String> result = Shell.SU.run("rm " + xgsFile);
      if (result != null) {
        success = true;
      }
    }

    return success;
  }

  private String getDumpFile() {

    FilenameFilter filter = new FilenameFilter() {
      @Override
      public boolean accept(File dir, String filename) {

        if (Build.MODEL.equals(Constants.MODEL_S3)) {
          if (filename.startsWith(Constants.LOG_FILE_S3_PREFIX)) {
            Log.d(LOG_TAG, "match: " + Constants.LOG_FILE_S3_PREFIX + ": " + filename);
    return true;
          }
        }
        if (Build.MODEL.equals(Constants.MODEL_S2)) {
          if (filename.startsWith(Constants.LOG_FILE_S2_PREFIX)) {
            Log.d(LOG_TAG, "match: " + Constants.LOG_FILE_S2_PREFIX + ": " + filename);
            return true;
          }
        }
        return false;
      }
    };
    String[] files = LOG_DIR_FILE.list(filter);

    if (files.length == 0) {
      Log.e(LOG_TAG, "No dumpfile found");
      return null;
    }
    Arrays.sort(files);

    String dumpFile = files[files.length - 1];
    return dumpFile;
  }

  public static void copyAndGzipFile(File src, File dst, final int fileNumber) throws IOException {
    copyAndGzipFile(src, dst, fileNumber, true);
  }

  public static void copyAndGzipFile(File src, File dst, final int fileNumber, boolean filter) throws IOException {
    if (Utils.isGalaxyS2()) {
      filter = false;
    }
    Log.d(Constants.LOG_TAG, "copyAndGzipFile: Copying file #" + fileNumber + ": " + src + " -> " + dst);
    final byte[] lastMatch = (match != null) ? match.clone() : null;

    try {

      FileInputStream in = new FileInputStream(src);
      OutputStream out = new GZIPOutputStream(new FileOutputStream(dst), BUFFER_SIZE);

      byte[] buf = new byte[BUFFER_SIZE];
      int len;
      boolean pastMatch = false;
      boolean bytesWritten = false;
      while ((len = in.read(buf)) > 0) {
        if (!filter || (lastMatch == null || pastMatch)) {
          out.write(buf, 0, len);
          bytesWritten = true;
        } else if (lastMatch != null) {
          pastMatch = Utils.checkForMatch(buf, lastMatch, in.getChannel());
        }
      }

      if (filter) {
        match = Arrays.copyOfRange(buf, buf.length - MATCH_LENGTH, buf.length); // last MATCH_LENGTH bytes
        Log.d(Constants.LOG_TAG, "Next match: " + Utils.byteArrayToHexString(match, 0, 10) + "...");
      }

      in.close();
      out.close();

      // If nothing was written do it again. This time without filtering
      if (!bytesWritten) {
        Log.d(LOG_TAG, "Pattern not found. Try again without filter");
        match = null;
        copyAndGzipFile(src, dst, fileNumber, false);
      } else {
          Log.d(LOG_TAG, "Bytes were written");
      }
    } catch (FileNotFoundException e) {

      Log.w(Constants.LOG_TAG, "FileNotFoundException. On File #" + fileNumber
                               + ": "
                               + src
                               + " Retrying in 1 second...");
      SystemClock.sleep(1000);
      if (!src.exists()) {
        Log.e(Constants.LOG_TAG, "File #" + fileNumber + ": " + src + " does not exist");
        return;
      }
        
      int retry = 0;
      while (!src.canRead() && retry < MAX_RETRY) {

        Shell.SH.run("ls -la " + src);
        Log.w(Constants.LOG_TAG, "Can't read File #" + fileNumber + ": " + src + " Retrying in " + retry + " second...");
        SystemClock.sleep(1000 * retry);
        retry++;
      }
      copyAndGzipFile(src, dst, fileNumber);
    }
    Log.d(Constants.LOG_TAG, "copyAndGzipFile end.");

  }

  public File getOutFile() {
    return outFile;
  }

  public long getTimestamp() {
    return timestamp;
  }

}
