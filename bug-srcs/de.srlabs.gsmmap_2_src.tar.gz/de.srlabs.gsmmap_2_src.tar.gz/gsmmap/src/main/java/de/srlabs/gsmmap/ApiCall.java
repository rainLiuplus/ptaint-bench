package de.srlabs.gsmmap;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.Locale;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import android.content.res.AssetManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

/**
 * @author Andreas Schildbach
 */
public abstract class ApiCall extends Thread {

  public enum Action {
    CALL, SMS, IGNORE
  }

  private final Action action;
  private final String number;
  private final AssetManager assets;
  private final Handler callbackHandler;

  public ApiCall(final Action action, final String number, final AssetManager assets) {
    this.action = action;
    this.number = number;
    this.assets = assets;
    this.callbackHandler = new Handler(Looper.myLooper());
  }

  @Override
  public void run() {

    HttpURLConnection connection = null;

    try {

      final URL url = new URL(Constants.API_URL + "&client_MSISDN="
                              + URLEncoder.encode(number)
                              + "&requested_action="
                              + action.name().toLowerCase(Locale.US));

      Log.i(Constants.LOG_TAG, "invoking api: " + url);
      final long start = System.currentTimeMillis();

      connection = (HttpURLConnection) url.openConnection();

      if (connection instanceof HttpsURLConnection) {
        final InputStream keystoreInputStream = assets.open("keystore.bks");

        final KeyStore keystore = KeyStore.getInstance("BKS");
        keystore.load(keystoreInputStream, "password".toCharArray());
        keystoreInputStream.close();

        final TrustManagerFactory tmf = TrustManagerFactory.getInstance("X509");
        tmf.init(keystore);

        final SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, tmf.getTrustManagers(), null);

        ((HttpsURLConnection) connection).setSSLSocketFactory(sslContext.getSocketFactory());
      }

      connection.setConnectTimeout((int) Constants.CONNECT_TIMEOUT);
      connection.setReadTimeout((int) Constants.READ_TIMEOUT);
      connection.setInstanceFollowRedirects(false);
      connection.connect();

      final int responseCode = connection.getResponseCode();
      final long duration = System.currentTimeMillis() - start;
      if (responseCode == HttpURLConnection.HTTP_OK) {
        callbackHandler.post(new Runnable() {
          @Override
          public void run() {
            Log.i(Constants.LOG_TAG, "invoking api succeeded, took " + duration + " ms");
            onSuccess();
          }
        });
      } else {
        Log.w(Constants.LOG_TAG, "api response: " + responseCode + " " + connection.getResponseMessage());
        callbackHandler.post(new Runnable() {
          @Override
          public void run() {
            Log.i(Constants.LOG_TAG, "invoking api failed with error code " + responseCode
                                     + ", took "
                                     + duration
                                     + " ms");
            onFail();
          }
        });
      }
    } catch (final IOException x) {
      Log.e(Constants.LOG_TAG, "error invoking api: " + x.getMessage());
    } catch (final GeneralSecurityException x) {
      Log.e(Constants.LOG_TAG, "error invoking api: " + x.getMessage());
    } finally {
      connection.disconnect();
    }
  }

  protected abstract void onSuccess();

  protected abstract void onFail();
}
