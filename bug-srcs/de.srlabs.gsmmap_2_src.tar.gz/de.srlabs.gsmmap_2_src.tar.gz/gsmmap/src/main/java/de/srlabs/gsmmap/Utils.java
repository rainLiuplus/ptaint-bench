package de.srlabs.gsmmap;

import android.content.Context;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.Log;
import eu.chainfire.libsuperuser.Shell;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;

import static de.srlabs.gsmmap.Constants.LOG_DIR_FILE;
import static de.srlabs.gsmmap.Constants.LOG_TAG;

public class Utils {

  private Utils() {
    //private constructor for utility class
  }

  public static boolean isRootNeededForRead() {
    return LOG_DIR_FILE.canRead();
  }

  public static boolean isRootNeededForDelete() {
    return LOG_DIR_FILE.canWrite();
  }

  public static String networkToConnectionType(final int networkType) {
    if (networkType == 0)
      return null;
    else if (networkType == TelephonyManager.NETWORK_TYPE_UMTS || networkType == TelephonyManager.NETWORK_TYPE_HSDPA
             || networkType == TelephonyManager.NETWORK_TYPE_HSPA
             || networkType == TelephonyManager.NETWORK_TYPE_HSPAP
             || networkType == TelephonyManager.NETWORK_TYPE_HSUPA)
      return Buckets.BUCKET_3G;
    else if (networkType == TelephonyManager.NETWORK_TYPE_GPRS || networkType == TelephonyManager.NETWORK_TYPE_EDGE
             || networkType == TelephonyManager.NETWORK_TYPE_CDMA)
      return Buckets.BUCKET_2G;
    else
      throw new IllegalStateException(Integer.toString(networkType));
  }

  /**
   * Finds a given byte[] within another byte[].
   * 
   * @param buf
   * @param pattern
   * @return true if buf contains pattern
   */
  public static boolean checkForMatch(byte[] buf, byte[] pattern) {
    return checkForMatch(buf, pattern, null);
  }

  /**
   * Finds a given byte[] within another byte[] and uses additional bytes from FileChannel if necessary.
   * 
   * @param buf
   * @param pattern
   * @param fileChannel
   * @return true if buf + bytes from fileChannel contains pattern
   */
  public static boolean checkForMatch(byte[] buf, byte[] pattern, FileChannel fileChannel) {
    if (pattern == null) {
      return false;
    }
    if (Arrays.equals(pattern, buf)) {
      return true;
    }

    for (int i = 0; i < buf.length; i++) {
      int startTmpBuf = i;
      int endTmpBuf = Math.min(pattern.length + i, buf.length);
      int tmpBufLength = endTmpBuf - startTmpBuf;

      if (tmpBufLength != pattern.length && equalsFromTo(buf, pattern, startTmpBuf, endTmpBuf)) {

        int missingBytesCount = pattern.length - tmpBufLength;

        byte[] missingBytes = peek(fileChannel, missingBytesCount);

        byte[] tmpBuf = Arrays.copyOfRange(buf, i, Math.min(pattern.length + i, buf.length));
        if (Arrays.equals(pattern, concat(tmpBuf, missingBytes))) {
          Log.v(LOG_TAG, "Match found with bytes from fileChannel");

          return true;
        }

      } else if (equalsFromTo(buf, pattern, startTmpBuf, endTmpBuf)) {
        Log.v(LOG_TAG, "Match found");

        return true;

      }

    }
    return false;
  }

  /**
   * Compare two byte array for equality up to a certain byte count length.
   * 
   * @param tmpBuf
   * @param buf
   * @param length
   * @return
   */
  public static boolean equalsUpTo(byte[] tmpBuf, byte[] buf, int length) {
    for (int i = 0; i < length; i++) {
      if (tmpBuf[i] == buf[i]) {

        continue;
      } else {
        return false;
      }
    }
    return true;
  }

  public static boolean equalsFromTo(byte[] src, byte[] match, int from, int to) {
    for (int i = from; i < to; i++) {
      if (src[i] == match[i - from]) {
        continue;
      } else {
        return false;
      }
    }
    return true;
  }

  public static byte[] concat(byte[] array1, byte[] array2) {

    byte[] result = new byte[array1.length + array2.length];
    int i;
    for (i = 0; i < array1.length; i++) {
      result[i] = array1[i];
    }
    for (int j = 0; j + i < result.length; j++) {
      result[j + i] = array2[j];
    }
    //    Log.d(LOG_TAG, "joined array:  " + Utils.byteArrayToHexString(result));
    return result;
  }

  public static byte[] peek(FileChannel fileChannel, int missingBytesCount) {
    if (fileChannel == null) {
      return new byte[] {};
    }
    byte[] result = new byte[missingBytesCount];

    try {
      long oldPosition = fileChannel.position();
      ByteBuffer buffer = ByteBuffer.allocate(missingBytesCount);
      fileChannel.read(buffer);

      for (int i = 0; i < missingBytesCount; i++) {
        result[i] = buffer.get(i);
      }
      fileChannel.position(oldPosition);

    } catch (IOException e) {
      Log.e(LOG_TAG, "Exception: ", e);
    }
    return result;
  }

  public static String byteArrayToHexString(byte[] data, int offset, int length) {
    final char[] hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
    char[] buf = new char[length * 3];
    int offs = 0;

    for (int i = 0; i < length; i++) {
      buf[offs++] = hex[(data[offset + i] >> 4) & 0xf];
      buf[offs++] = hex[(data[offset + i] >> 0) & 0xf];
      buf[offs++] = ' ';
    }

    return new String(buf, 0, offs);
  }

  public static String byteArrayToHexString(byte[] data) {
    if (data == null) {
      return null;
    }
    return byteArrayToHexString(data, 0, data.length);
  }

  public static boolean isGalaxyS3() {
    return Build.MODEL.equals(Constants.MODEL_S3);
  }

  public static boolean isGalaxyS2() {
    return Build.MODEL.equals(Constants.MODEL_S2);
  }

  public static long uploadSize(final Context context) {
    long size = 0;

    for (final File file : context.getExternalFilesDir(null).listFiles())
      if (file.isFile()) size += file.length();

    return size;
  }

  public static void deleteLogFilesWithPrefix(final String[] filePrefix) {
    new Thread(new Runnable() {
      @Override
      public void run() {

        for (String prefix : filePrefix) {

          Shell.SU.run("rm " + LOG_DIR_FILE.getAbsolutePath() + "/" + prefix + "*");

        }
      }
    }).start();
  }
}
