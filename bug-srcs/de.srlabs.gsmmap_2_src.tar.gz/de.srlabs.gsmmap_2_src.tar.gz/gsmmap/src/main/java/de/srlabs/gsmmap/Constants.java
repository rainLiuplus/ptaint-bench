package de.srlabs.gsmmap;

import java.io.File;

import android.text.format.DateUtils;

/**
 * @author Andreas Schildbach
 */
public class Constants {

  public static final int MAX_ITERATIONS = 5;
  public static final String LOG_TAG = Constants.class.getPackage().getName();
  public static final String CALL_NUMBER = "+14046206543"; // use '+' notation
  public static final String CALLBACK_NUMBER = "+14046206545";
  public static final long TEST_TIMEOUT = DateUtils.SECOND_IN_MILLIS * 120;
  public static final String UPLOAD_URL = "https://gsmmap.srlabs.de:4433/cgi-bin/dat_upload.cgi";
  public static final String API_URL = "https://brest.srlabs.de:4443/clientCommandReceiver.php?Password=gdsajsdgkgdsalkgfdsgsdrw43435swds";
  public static final String MULTIPART_BOUNDARY = "**********";
  public static final String CRLF = "\r\n";
  public static final long CONNECT_TIMEOUT = 20 * DateUtils.SECOND_IN_MILLIS;
  public static final long READ_TIMEOUT = 20 * DateUtils.SECOND_IN_MILLIS;
  public static final long SMSBACK_TIMEOUT = 60 * DateUtils.SECOND_IN_MILLIS;
  public static final long CALLBACK_TIMEOUT = 30 * DateUtils.SECOND_IN_MILLIS;
  public static final String SMS_NUMBER = "0";
  public static final String SMS_CENTER = "0";

  public static final File LOG_DIR_FILE = new File("/data/log/err/");

  public static final String MODEL_S2 = "GT-I9100";
  public static final String MODEL_S3 = "GT-I9300";

  public static final String LOG_FILE_S3_PREFIX = "CPLOG_ISTP_TRACE";
  public static final String LOG_FILE_S2_PREFIX = "MA_TRACE_";
  public static final String LOG_FILE_S2_PREFIX_AENAES = "AENEAS_TRACE_";
  public static final String LOG_FILE_XGS_PREFIX = "xgs.";

  public static final String PREFS_KEY_OWN_NUMBER = "own_number";
  public static final String MAP_URL = "https://gsmmap.org/";
}
