package de.srlabs.gsmmap;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;

/**
 * @author Andreas Schildbach
 */
public abstract class SmsReceiver extends BroadcastReceiver {

  @Override
  public void onReceive(final Context context, final Intent intent) {

    final Bundle extras = intent.getExtras();

    boolean swallowSms = true;

    if (extras != null) {
      final Object[] pdus = (Object[]) extras.get("pdus");

      for (final Object pdu : pdus) {

        final SmsMessage sms = SmsMessage.createFromPdu((byte[]) pdu);

        final String originatingAddress = sms.getOriginatingAddress();
        if (Constants.CALL_NUMBER.equals(originatingAddress) || Constants.CALLBACK_NUMBER.equals(originatingAddress)) {
          onReceiveSms(sms);
        } else {
          swallowSms = false;
        }
      }
    }

    // we don't want our spam to appear in the user's inbox
    if (swallowSms) abortBroadcast();
  }

  protected abstract void onReceiveSms(SmsMessage sms);
}
