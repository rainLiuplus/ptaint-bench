package mirror.android.app;

import mirror.RefClass;
import mirror.RefObject;

/**
 * @author Lody
 */

public class LoadedApkHuaWei {
    public static Class<?> TYPE = RefClass.load(LoadedApkHuaWei.class, "android.app.LoadedApk");
    public static RefObject<Object> mReceiverResource;
}
