package com.lody.virtual.server.pm.installer;

/**
 * @author Lody
 */

public class PackageInstallInfo {

}
