package mirror.android.app;

import android.app.PendingIntent;
import android.content.Intent;

import mirror.RefClass;
import mirror.RefMethod;

public class PendingIntentJBMR2 {
    public static Class Class = RefClass.load(PendingIntentJBMR2.class, PendingIntent.class);
    public static RefMethod<Intent> getIntent;
}