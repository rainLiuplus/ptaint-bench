//
// VirtualApp Native Project
//

#ifndef FOUNDATION_PATH
#define FOUNDATION_PATH

#include <string.h>

int get_last_slash_pos(char *s);

char* canonicalize_filename(const char *str);


#endif //FOUNDATION_PATH
