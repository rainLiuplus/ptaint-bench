# android-xmrig-miner
XMRig miner built inside an android app


This app is based on the proof of concept provided by https://github.com/upost/MoneroMiner

I updated dependencies (libuv-1.23.1 and xmrig-2.8.0-rc)and the project to Android Studio 3.2.


# Compile instructions

Read and follow the instructions in settings.gradle.


# Dependencies

Android Studio.
Download both SDK and NDK with sdk-manager.

# Releases
... coming soon ...

# Credits
libuv by http://libuv.org
xmrig by https://github.com/xmrig

Original project set up:
https://github.com/upost/MoneroMiner


